# API 명세

## 1. 회원가입
```
POST /api/auth/signup
```

**요청**
```json
{
  "username": "testuser",
  "password": "password123",
  "email": "test@example.com"
}
```

**응답**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "username": "testuser"
}
```

---

## 2. 로그인
```
POST /api/auth/login
```

**요청**
```json
{
  "username": "testuser",
  "password": "password123"
}
```

**응답**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "username": "testuser"
}
```

---

## 3. Hello (JWT 필요)
```
GET /api/user/hello
Authorization: Bearer {token}
```

**응답**
```
안녕하세요, testuser님!
```

