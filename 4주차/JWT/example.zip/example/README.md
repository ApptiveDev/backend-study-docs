# JWT 인터셉터 예시 프로젝트

Spring Boot와 JWT를 사용한 간단한 인증 시스템 예제입니다.

## 기술 스택
- Spring Boot 3.5.7
- Java 21
- H2 Database (인메모리)
- JWT (JSON Web Token)
- Lombok
- Spring Data JPA

## 프로젝트 구조 (초보자용으로 최소화!)

```
src/main/java/dev/jun0/example/
├── config/
│   └── WebConfig.java              # 인터셉터 등록
├── controller/
│   ├── AuthController.java         # 로그인/회원가입 (단 60줄!)
│   └── UserController.java         # 보호된 API
├── entity/
│   └── Member.java                 # 회원 엔티티
├── interceptor/
│   └── JwtInterceptor.java         # JWT 검증 인터셉터 ⭐
├── repository/
│   └── MemberRepository.java       # JPA Repository
├── util/
│   └── JwtUtil.java                # JWT 유틸 (단 50줄!)
└── ExampleApplication.java         # 메인
```

**총 7개 파일로 JWT 인터셉터 완성!**

## 실행 방법

1. 프로젝트 빌드
```bash
./gradlew build
```

2. 애플리케이션 실행
```bash
./gradlew bootRun
```

3. H2 콘솔 접속 (선택사항)
- URL: http://localhost:8080/h2-console
- JDBC URL: jdbc:h2:mem:testdb
- Username: sa
- Password: (비워두기)

## API 사용법

### 1. 회원가입
```bash
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123",
    "email": "test@example.com"
  }'
```

**응답 예시:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "username": "testuser"
}
```

### 2. 로그인
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }'
```

**응답 예시:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "username": "testuser"
}
```

### 3. 프로필 조회 (JWT 필요)
```bash
curl -X GET http://localhost:8080/api/user/profile \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**응답 예시:**
```json
{
  "id": 1,
  "username": "testuser",
  "email": "test@example.com"
}
```

### 4. Hello 메시지 (JWT 필요)
```bash
curl -X GET http://localhost:8080/api/user/hello \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**응답 예시:**
```
안녕하세요, testuser님!
```

## 주요 개념 설명

### JWT 인터셉터란?
- Spring MVC의 `HandlerInterceptor`를 구현하여 컨트롤러 실행 전에 JWT 토큰을 검증합니다.
- `preHandle` 메서드에서 요청의 Authorization 헤더를 확인하고 토큰을 검증합니다.

### 동작 흐리
1. 클라이언트가 로그인/회원가입 → JWT 토큰 발급
2. 클라이언트가 보호된 API 호출 시 Authorization 헤더에 토큰 포함
3. `JwtInterceptor`가 토큰을 검증
4. 검증 성공 시 컨트롤러 실행, 실패 시 401 에러 반환

### 인터셉터 설정
`WebConfig`에서 인터셉터를 등록하고 적용할 경로를 지정합니다:
- `/api/**` : 인터셉터 적용
- `/api/auth/**` : 인터셉터 제외 (로그인/회원가입은 토큰 없이 접근 가능)

## 주의사항

⚠️ **이 프로젝트는 학습용 예제입니다. 실제 프로덕션 환경에서는 다음 사항을 반드시 적용해야 합니다:**

1. **비밀번호 암호화**: BCrypt 등을 사용하여 비밀번호를 암호화해야 합니다.
2. **JWT Secret 관리**: 환경 변수로 관리하고 충분히 긴 시크릿 키를 사용해야 합니다.
3. **에러 처리**: 전역 예외 처리기를 구현해야 합니다.
4. **토큰 갱신**: Refresh Token을 구현해야 합니다.
5. **HTTPS 사용**: 프로덕션에서는 반드시 HTTPS를 사용해야 합니다.

## 라이선스
MIT

