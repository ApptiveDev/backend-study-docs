package dev.jun0.example.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/user")
public class UserController {
    
    // JWT 인터셉터를 통과한 사용자만 접근 가능
    @GetMapping("/hello")
    public String hello(HttpServletRequest request) {
        String username = (String) request.getAttribute("username");
        return "안녕하세요, " + username + "님!";
    }
}

