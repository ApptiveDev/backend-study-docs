package dev.jun0.example.controller;

import dev.jun0.example.entity.Member;
import dev.jun0.example.repository.MemberRepository;
import dev.jun0.example.util.JwtUtil;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    private final MemberRepository memberRepository;
    private final JwtUtil jwtUtil;
    
    public AuthController(MemberRepository memberRepository, JwtUtil jwtUtil) {
        this.memberRepository = memberRepository;
        this.jwtUtil = jwtUtil;
    }
    
    // 회원가입
    @PostMapping("/signup")
    public Map<String, String> signup(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        String email = request.get("email");
        
        // 중복 체크
        if (memberRepository.existsByUsername(username)) {
            return Map.of("error", "이미 존재하는 사용자명입니다.");
        }
        
        // 회원 저장
        Member member = new Member(username, password, email);
        memberRepository.save(member);
        
        // JWT 토큰 생성
        String token = jwtUtil.generateToken(username);
        
        return Map.of("token", token, "username", username);
    }
    
    // 로그인
    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        
        // 사용자 조회
        Member member = memberRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다."));
        
        // 비밀번호 확인
        if (!member.getPassword().equals(password)) {
            throw new RuntimeException("비밀번호가 일치하지 않습니다.");
        }
        
        // JWT 토큰 생성
        String token = jwtUtil.generateToken(username);
        
        return Map.of("token", token, "username", username);
    }
}

